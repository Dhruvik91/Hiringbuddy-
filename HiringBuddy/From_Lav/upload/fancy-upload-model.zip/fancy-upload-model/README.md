# Fancy upload model

A Pen created on CodePen.io. Original URL: [https://codepen.io/jgnacademy/pen/jOKeNpL](https://codepen.io/jgnacademy/pen/jOKeNpL).

